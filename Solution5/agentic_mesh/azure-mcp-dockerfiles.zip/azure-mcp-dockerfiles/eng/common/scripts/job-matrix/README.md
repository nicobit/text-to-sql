# Azure Pipelines Matrix Generator

The documentation for Azure Pipelines Matrix Generator can be found at

[`azure-sdk-tools/doc/common/matrix_generator.md`](https://github.com/Azure/azure-sdk-tools/blob/main/doc/common/matrix_generator.md)
