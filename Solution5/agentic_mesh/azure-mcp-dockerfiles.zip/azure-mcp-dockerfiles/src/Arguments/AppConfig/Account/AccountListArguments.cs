// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.AppConfig.Account;

public class AccountListArguments : SubscriptionArguments;
