// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.Cosmos;

public class ContainerListArguments : BaseDatabaseArguments;
