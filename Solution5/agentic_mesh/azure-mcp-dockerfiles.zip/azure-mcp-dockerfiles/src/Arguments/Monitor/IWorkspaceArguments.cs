// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.Monitor;

public interface IWorkspaceArguments
{
    string? Workspace { get; set; }
}
