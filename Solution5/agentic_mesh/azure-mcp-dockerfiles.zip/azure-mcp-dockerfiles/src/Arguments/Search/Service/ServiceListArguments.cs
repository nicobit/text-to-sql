// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.Search.Service;

public class ServiceListArguments : SubscriptionArguments;
