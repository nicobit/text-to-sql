// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.Storage.Table;

public class TableListArguments : BaseStorageArguments;
