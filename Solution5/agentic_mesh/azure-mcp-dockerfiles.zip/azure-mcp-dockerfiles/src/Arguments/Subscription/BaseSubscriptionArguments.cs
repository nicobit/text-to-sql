// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.Subscription;

public class BaseSubscriptionArguments : GlobalArguments;
