// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.AppConfig.KeyValue;

public class KeyValueDeleteArguments : BaseKeyValueArguments;
