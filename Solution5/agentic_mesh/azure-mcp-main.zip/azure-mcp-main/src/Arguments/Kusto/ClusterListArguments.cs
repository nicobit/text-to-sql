// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.Kusto;

public class ClusterListArguments : BaseClusterArguments;
