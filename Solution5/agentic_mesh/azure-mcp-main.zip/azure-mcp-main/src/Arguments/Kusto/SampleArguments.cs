// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.Kusto;

public class SampleArguments : BaseTableArguments
{
    public int? Limit { get; set; }
}
