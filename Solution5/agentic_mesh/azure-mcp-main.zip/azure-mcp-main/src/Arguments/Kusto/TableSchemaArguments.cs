// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using System.Text.Json.Serialization;

namespace AzureMcp.Arguments.Kusto;

public class TableSchemaArguments : BaseTableArguments;
