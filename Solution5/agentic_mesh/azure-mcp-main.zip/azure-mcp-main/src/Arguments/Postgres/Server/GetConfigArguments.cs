// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.Postgres.Server;

public class GetConfigArguments : BasePostgresArguments;
