// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.Search.Index;

public class IndexListArguments : BaseSearchArguments;
