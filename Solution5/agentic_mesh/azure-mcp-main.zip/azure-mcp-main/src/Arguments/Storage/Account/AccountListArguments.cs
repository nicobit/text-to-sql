// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.Storage.Account;

public class AccountListArguments : SubscriptionArguments;
