// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

namespace AzureMcp.Arguments.Storage.Blob;

public class BlobListArguments : BaseContainerArguments;
