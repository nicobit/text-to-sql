from langchain_core.documents import Document

__all__ = ["Document"]
