from thinc.extra.search import MaxViolation


def test_init_violn():
    MaxViolation()
