import azure.functions as func
from azure.functions import AsgiFunctionApp
from api import app as fastapi_app

handler = AsgiFunctionApp(app=fastapi_app, http_auth_level=func.AuthLevel.ANONYMOUS)

def main(req: func.HttpRequest) -> func.HttpResponse:
    return handler(req)